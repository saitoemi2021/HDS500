#' Emi's Play into Packages
#'
#' An attempt to develop a package to estimate needed sample size
#' to compare 2 proportions, based on a preliminary trial, in a larger study.
#'
#' Wish me luck!
#'
#' @param p1 proportion of those in group 1 that have characteristic of interest
#' @param p2 proportion of those in group 2 that have characteristic of interest
#' @param h effect size for a 2 proportions test
#' @return A list of statistics from the 2 proportions calculator, including alpha, power, effect size and minimimum n
#'
#' Loading required packages
#' @importFrom pwr
#' @importFrom tidyverse
#' @importFrom RSQLite
#'
#' library(pwr)
#' library(RSQLite)
#' library(tidyverse)
#'
#'
#' #Data for this example - I can't believe I actually figured out how to load the excel data into the package as an rda!
#' data('SampleData')
#' data <- SampleData %>%
#'  mutate(WtLoss = if_else(Post12_5percentloss==1, "LostWt", "NotLoseWt")) %>%
#'  mutate(OW = if_else(OBESITY_1ST_DX == "Y", "OW/Obese", "Not OW/Obese"))
#'
#' #Calculating effect size from sample dataset:
#' ContingencyTable <- table(data1$WtLoss, data1$OW)
#' ContingencyTable <- addmargins(ContingencyTable)
#' p1 = ContingencyTable[1,1]/ContingencyTable[3,1]
#' p2 = ContingencyTable[1,2]/ContingencyTable[3,2]
#' h=2*asin(sqrt(p1))-2*asin(sqrt(p2))
#'
#' Calculate sample size, assuming alpha=0.05 and power = 0.08
#' pwr.2p.test(h, sig.level=0.05, power=0.80, alternative="two.sided")
